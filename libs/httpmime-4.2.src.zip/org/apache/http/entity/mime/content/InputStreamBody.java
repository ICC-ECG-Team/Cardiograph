/*    */ package org.apache.http.entity.mime.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class InputStreamBody extends AbstractContentBody
/*    */ {
/*    */   private final InputStream in;
/*    */   private final String filename;
/*    */ 
/*    */   public InputStreamBody(InputStream in, String mimeType, String filename)
/*    */   {
/* 46 */     super(mimeType);
/* 47 */     if (in == null) {
/* 48 */       throw new IllegalArgumentException("Input stream may not be null");
/*    */     }
/* 50 */     this.in = in;
/* 51 */     this.filename = filename;
/*    */   }
/*    */ 
/*    */   public InputStreamBody(InputStream in, String filename) {
/* 55 */     this(in, "application/octet-stream", filename);
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream() {
/* 59 */     return this.in;
/*    */   }
/*    */ 
/*    */   public void writeTo(OutputStream out) throws IOException {
/* 63 */     if (out == null)
/* 64 */       throw new IllegalArgumentException("Output stream may not be null");
/*    */     try
/*    */     {
/* 67 */       byte[] tmp = new byte[4096];
/*    */ 
/* 69 */       while ((l = this.in.read(tmp)) != -1)
/*    */       {
/*    */         int l;
/* 70 */         out.write(tmp, 0, l);
/*    */       }
/* 72 */       out.flush();
/*    */     } finally {
/* 74 */       this.in.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getTransferEncoding() {
/* 79 */     return "binary";
/*    */   }
/*    */ 
/*    */   public String getCharset() {
/* 83 */     return null;
/*    */   }
/*    */ 
/*    */   public long getContentLength() {
/* 87 */     return -1L;
/*    */   }
/*    */ 
/*    */   public String getFilename() {
/* 91 */     return this.filename;
/*    */   }
/*    */ }

/* Location:           C:\Users\yjx\Desktop\httpmime-4.2.jar
 * Qualified Name:     org.apache.http.entity.mime.content.InputStreamBody
 * JD-Core Version:    0.5.4
 */