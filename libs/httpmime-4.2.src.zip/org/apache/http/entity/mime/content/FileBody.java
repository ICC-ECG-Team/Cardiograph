/*     */ package org.apache.http.entity.mime.content;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class FileBody extends AbstractContentBody
/*     */ {
/*     */   private final File file;
/*     */   private final String filename;
/*     */   private final String charset;
/*     */ 
/*     */   public FileBody(File file, String filename, String mimeType, String charset)
/*     */   {
/*  55 */     super(mimeType);
/*  56 */     if (file == null) {
/*  57 */       throw new IllegalArgumentException("File may not be null");
/*     */     }
/*  59 */     this.file = file;
/*  60 */     if (filename != null)
/*  61 */       this.filename = filename;
/*     */     else
/*  63 */       this.filename = file.getName();
/*  64 */     this.charset = charset;
/*     */   }
/*     */ 
/*     */   public FileBody(File file, String mimeType, String charset)
/*     */   {
/*  73 */     this(file, null, mimeType, charset);
/*     */   }
/*     */ 
/*     */   public FileBody(File file, String mimeType) {
/*  77 */     this(file, mimeType, null);
/*     */   }
/*     */ 
/*     */   public FileBody(File file) {
/*  81 */     this(file, "application/octet-stream");
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream() throws IOException {
/*  85 */     return new FileInputStream(this.file);
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream out) throws IOException {
/*  89 */     if (out == null) {
/*  90 */       throw new IllegalArgumentException("Output stream may not be null");
/*     */     }
/*  92 */     InputStream in = new FileInputStream(this.file);
/*     */     try {
/*  94 */       byte[] tmp = new byte[4096];
/*     */ 
/*  96 */       while ((l = in.read(tmp)) != -1)
/*     */       {
/*     */         int l;
/*  97 */         out.write(tmp, 0, l);
/*     */       }
/*  99 */       out.flush();
/*     */     } finally {
/* 101 */       in.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getTransferEncoding() {
/* 106 */     return "binary";
/*     */   }
/*     */ 
/*     */   public String getCharset() {
/* 110 */     return this.charset;
/*     */   }
/*     */ 
/*     */   public long getContentLength() {
/* 114 */     return this.file.length();
/*     */   }
/*     */ 
/*     */   public String getFilename() {
/* 118 */     return this.filename;
/*     */   }
/*     */ 
/*     */   public File getFile() {
/* 122 */     return this.file;
/*     */   }
/*     */ }

/* Location:           C:\Users\yjx\Desktop\httpmime-4.2.jar
 * Qualified Name:     org.apache.http.entity.mime.content.FileBody
 * JD-Core Version:    0.5.4
 */