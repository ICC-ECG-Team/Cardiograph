/*    */ package org.apache.http.entity.mime;
/*    */ 
/*    */ public enum HttpMultipartMode
/*    */ {
/* 37 */   STRICT, 
/*    */ 
/* 39 */   BROWSER_COMPATIBLE;
/*    */ }

/* Location:           C:\Users\yjx\Desktop\httpmime-4.2.jar
 * Qualified Name:     org.apache.http.entity.mime.HttpMultipartMode
 * JD-Core Version:    0.5.4
 */